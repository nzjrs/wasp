Here is the folder for the drivers and sample applications for the OpenSource InterFace (OSIF)

Version 2 is the latest branch, and this is the branch that should be used.

Folders:
Version_1   - Old branch of drivers
Version_2   - New branch. You should be using this
