<rss version="2.0" xmlns:dc="http://purl.org/dc/elements/1.1/">
  

  <channel>
    <title>Revisions of /trunk/src/libprs500/libusb.py</title>
    <link>https://libprs500.kovidgoyal.net/log/trunk/src/libprs500/libusb.py?rev=198</link>
    <description>Trac Log - Revisions of /trunk/src/libprs500/libusb.py</description>
    <language>en-US</language>
    <generator>Trac 0.11dev</generator>
    <image>
      <title>libprs500</title>
      <url>/chrome/site/libprs500_banner.png</url>
      <link>https://libprs500.kovidgoyal.net/log/trunk/src/libprs500/libusb.py?rev=198</link>
    </image>
    <item>
          <dc:creator>kovid</dc:creator>
      <pubDate>Wed, 17 Jan 2007 19:41:35 GMT</pubDate>
      <title>Revision 198: Minor cleanups.</title>
      <link>https://libprs500.kovidgoyal.net/changeset/198/trunk/src/libprs500/libusb.py</link>
      <guid isPermaLink="false">https://libprs500.kovidgoyal.net/changeset/198/trunk/src/libprs500/libusb.py</guid>
      <description>Minor cleanups.</description>
      <category>Log</category>
    </item><item>
          <dc:creator>kovid</dc:creator>
      <pubDate>Tue, 16 Jan 2007 22:06:39 GMT</pubDate>
      <title>Revision 197: #21 fixed in previous revision. Version bump.</title>
      <link>https://libprs500.kovidgoyal.net/changeset/198/trunk/src/libprs500/libusb.py</link>
      <guid isPermaLink="false">https://libprs500.kovidgoyal.net/changeset/197/trunk/src/libprs500/libusb.py</guid>
      <description>&lt;a class="closed ticket" href="https://libprs500.kovidgoyal.net/ticket/21" title="Not working in Windows (closed)"&gt;#21&lt;/a&gt; fixed in previous revision. Version bump.</description>
      <category>Log</category>
    </item><item>
          <dc:creator>kovid</dc:creator>
      <pubDate>Tue, 16 Jan 2007 22:02:34 GMT</pubDate>
      <title>Revision 196: Windows configuration bug should be fixed.</title>
      <link>https://libprs500.kovidgoyal.net/changeset/198/trunk/src/libprs500/libusb.py</link>
      <guid isPermaLink="false">https://libprs500.kovidgoyal.net/changeset/196/trunk/src/libprs500/libusb.py</guid>
      <description>Windows configuration bug should be fixed.</description>
      <category>Log</category>
    </item><item>
          <dc:creator>kovid</dc:creator>
      <pubDate>Tue, 16 Jan 2007 20:33:15 GMT</pubDate>
      <title>Revision 195: Added a set configuration call to device initialization as this is needed  ...</title>
      <link>https://libprs500.kovidgoyal.net/changeset/198/trunk/src/libprs500/libusb.py</link>
      <guid isPermaLink="false">https://libprs500.kovidgoyal.net/changeset/195/trunk/src/libprs500/libusb.py</guid>
      <description>Added a set configuration call to device initialization as this is needed in windows and doesn't seem to matter in linux. Fixed BBeBook.</description>
      <category>Log</category>
    </item><item>
          <dc:creator>kovid</dc:creator>
      <pubDate>Tue, 16 Jan 2007 19:57:23 GMT</pubDate>
      <title>Revision 194: Added set_configuration method in libusb</title>
      <link>https://libprs500.kovidgoyal.net/changeset/198/trunk/src/libprs500/libusb.py</link>
      <guid isPermaLink="false">https://libprs500.kovidgoyal.net/changeset/194/trunk/src/libprs500/libusb.py</guid>
      <description>Added set_configuration method in libusb</description>
      <category>Log</category>
    </item><item>
          <dc:creator>kovid</dc:creator>
      <pubDate>Tue, 16 Jan 2007 19:07:12 GMT</pubDate>
      <title>Revision 193: i hate windows</title>
      <link>https://libprs500.kovidgoyal.net/changeset/198/trunk/src/libprs500/libusb.py</link>
      <guid isPermaLink="false">https://libprs500.kovidgoyal.net/changeset/193/trunk/src/libprs500/libusb.py</guid>
      <description>i hate windows</description>
      <category>Log</category>
    </item><item>
          <dc:creator>kovid</dc:creator>
      <pubDate>Sat, 13 Jan 2007 19:27:30 GMT</pubDate>
      <title>Revision 191: Cleanups and minor bug fixes. ls -h works again. Various unicode related  ...</title>
      <link>https://libprs500.kovidgoyal.net/changeset/198/trunk/src/libprs500/libusb.py</link>
      <guid isPermaLink="false">https://libprs500.kovidgoyal.net/changeset/191/trunk/src/libprs500/libusb.py</guid>
      <description>Cleanups and minor bug fixes. ls -h works again. Various unicode related bugs squashed. Version bump.</description>
      <category>Log</category>
    </item><item>
          <dc:creator>kovid</dc:creator>
      <pubDate>Sat, 13 Jan 2007 07:29:15 GMT</pubDate>
      <title>Revision 188: Set correct PATH_MAX on OSX. Version bump.</title>
      <link>https://libprs500.kovidgoyal.net/changeset/198/trunk/src/libprs500/libusb.py</link>
      <guid isPermaLink="false">https://libprs500.kovidgoyal.net/changeset/188/trunk/src/libprs500/libusb.py</guid>
      <description>Set correct PATH_MAX on OSX. Version bump.</description>
      <category>Log</category>
    </item><item>
          <dc:creator>kovid</dc:creator>
      <pubDate>Sat, 13 Jan 2007 04:15:25 GMT</pubDate>
      <title>Revision 187: Drop dependency on PyUSB. Version bump.</title>
      <link>https://libprs500.kovidgoyal.net/changeset/198/trunk/src/libprs500/libusb.py</link>
      <guid isPermaLink="false">https://libprs500.kovidgoyal.net/changeset/187/trunk/src/libprs500/libusb.py</guid>
      <description>Drop dependency on PyUSB. Version bump.</description>
      <category>Log</category>
    </item><item>
          <dc:creator>kovid</dc:creator>
      <pubDate>Sat, 13 Jan 2007 03:14:06 GMT</pubDate>
      <title>Revision 186: Initial implementation of a ctypes based wrapper around libusb to replace  ...</title>
      <link>https://libprs500.kovidgoyal.net/changeset/198/trunk/src/libprs500/libusb.py</link>
      <guid isPermaLink="false">https://libprs500.kovidgoyal.net/changeset/186/trunk/src/libprs500/libusb.py</guid>
      <description>Initial implementation of a ctypes based wrapper around libusb to replace pyusb.</description>
      <category>Log</category>
    </item>
 </channel>
</rss>