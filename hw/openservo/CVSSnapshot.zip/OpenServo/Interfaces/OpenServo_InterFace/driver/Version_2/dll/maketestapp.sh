gcc testapp.c -L. -ldl -o testapp 
