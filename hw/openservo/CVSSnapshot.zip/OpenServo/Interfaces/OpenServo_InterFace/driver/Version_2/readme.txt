bootloader                - The bootloader for the OSIF
dll                       - The cross platform shared library and build scripts
firmware                  - The main firmware for the OSIF
kernel                    - The Linux kernel driver for /dev/i2c-x access
software                  - Various utilities for the OSIF
  |__bootloader_updater   - Text based OSIF firmware update program
usbtiny                   - The core software USB driver by Dick Streefland
util                      - USBTiny utilities
win                       - Windows driver and inf files
