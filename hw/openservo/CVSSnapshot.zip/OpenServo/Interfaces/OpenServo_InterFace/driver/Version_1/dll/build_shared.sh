make clean
make
ldconfig -n ./
