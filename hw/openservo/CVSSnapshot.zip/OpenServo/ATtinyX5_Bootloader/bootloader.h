/*
    Copyright (c) 2006 Michael P. Thompson <mpthompson@gmail.com>

    Permission is hereby granted, free of charge, to any person 
    obtaining a copy of this software and associated documentation 
    files (the "Software"), to deal in the Software without 
    restriction, including without limitation the rights to use, copy, 
    modify, merge, publish, distribute, sublicense, and/or sell copies 
    of the Software, and to permit persons to whom the Software is 
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be 
    included in all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
    EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
    NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT 
    HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
    WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
    DEALINGS IN THE SOFTWARE.

    $Id: bootloader.h,v 1.3 2006/02/08 22:41:33 mpthompson Exp $
*/

#ifndef _BOOTLOADER_H_
#define _BOOTLOADER_H_ 1

extern uint8_t bootloader_exit;
extern uint8_t bootloader_active;

// The BOOTLOADER_SECTION macro is used to locate functions into the bootloader
// section of the text segment.  Normally, the bootloader section is located
// in the upper 1024 bytes of Flash unless the bootstrap version of the software
// is being built.

#ifdef BOOTSTRAPPER
#define BOOTLOADER_SECTION
#else
#define BOOTLOADER_SECTION __attribute__ ((section (".bootloader")))
#endif

#endif // _BOOTLOADER_H_

