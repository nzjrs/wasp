AVR OpenServo Version 3 Hardware
================================

May 21st, 2007

Mike Thompson
mpthompson@gmail.com

This is the OpenServo firmware for the Version 3 hardware designed 
by Cliff Huston.  This firmware is under active development and can
be expected to change dramatically over the coming months as newer
features of the hardware are supported.
