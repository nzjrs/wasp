Motion Profile Application (c) Barry Carter 2007
barry.carter@gmail.com

released under the GNU GPL. See source for details.

This program uses Hermite curves to control an OpenServo. 

The OpenServo can store a buffer of 8 curves at once. This program send those curves in sequence.


Notes:
The Gradient of the curves is the velocity. The distance between control points is the Time Delta.

Be sure not to make your curves too steep. The OpenServo can only move as fast as the hardware will allow.

No more information at this time. Check back for a proper release.
